# Blizzard

Blizzard is a small Wii homebrew launcher for DOL and ELF payloads listed in an XML file. Its console menu uses a Wii Remote. It is an initial source release: it has not been built with devkitPro or tested on hardware or Dolphin in this environment. Test with disposable files and a known-good homebrew app first.

## Build

Install devkitPro's Wii development tools (devkitPPC, libogc and libfat), set `DEVKITPRO` and `DEVKITPPC` as required by your installation, then run `make`. Copy the resulting `Blizzard.dol` to `sd:/apps/Blizzard/boot.dol`. Copy `sd-card/apps/Blizzard/meta.xml` to the same folder. Launch Blizzard with the Homebrew Channel.

Copy `sd-card/payloads/payloads.xml` to `sd:/payloads/payloads.xml`, and put your actual payloads beneath `sd:/payloads/`. The supplied entries are examples only: no payload binaries are included.

```text
sd:/
  apps/Blizzard/boot.dol
  apps/Blizzard/meta.xml
  payloads/payloads.xml
  payloads/example/boot.dol
  payloads/tools/demo.elf
```

Blizzard itself and Homebrew Channel metadata live under `apps`; all configured payloads and their folders live under `payloads`.

## Configuration

```xml
<?xml version="1.0" encoding="UTF-8"?>
<payloads>
  <payload name="Example homebrew" path="example/boot.dol" />
  <payload name="Another payload" path="tools/demo.elf" />
</payloads>
```

Each `path` is a file path relative to `sd:/payloads/`; subdirectories are supported. Replace the examples with real DOL or ELF files. Paths must use forward slashes and cannot contain `.` or `..` components, device prefixes, or FAT-invalid characters. Names are displayed in the menu. Use XML entities such as `&amp;` and `&quot;` where needed. The deliberately limited reader accepts an optional XML declaration, a `<payloads>` root and self-closing `<payload name="..." path="..." />` entries only; it does not support XML comments, numeric entities, other tags or attributes. Up to 64 entries and a 32 KiB XML file are supported. Restart Blizzard after changing the file.

Use Up/Down to choose an entry, A to launch, and Home to exit. The console occupies the full framebuffer; some TVs may crop its edges due to overscan. Errors appear in the menu. Payloads should provide their own exit behavior; returning to Blizzard is not implemented.

## Compatibility and limitations

- Wii DOL and static 32-bit big-endian PowerPC ELF executables up to 8 MiB are supported. ELF loadable segments must expand to no more than 8 MiB in total (including zero-filled space and a 256-byte header). Dynamic ELF files, arguments, USB, and GameCube controllers are not supported.
- Blizzard checks DOL sections and ELF loadable segments for bounds and overlap, as well as the entry point. It only accepts sections and BSS in `0x80004000` through `0x8132ffff`, leaving loader/staging space untouched. Some valid homebrew uses other memory layouts and will be rejected.
- Launching shuts down Blizzard and transfers control to the DOL. There is no sandbox, so an executable can access or modify the console and files. Only run payloads you trust. Payloads may themselves expect resources outside `sd:/payloads`; Blizzard does not rewrite their file access.
- The loader stages the executable and its relocation stub in MEM2 and does not supply argv. Compatibility depends on the target homebrew's startup requirements. Verify on Dolphin and real hardware before relying on it.
