#include <gccore.h>
#include <wiiuse/wpad.h>
#include <fat.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>

#define MAX_ITEMS 64
#define MAX_XML 32768
#define MAX_DOL (8u*1024u*1024u)
#define STAGING ((unsigned char *)0x92000000)
#define STUB ((void *)0x93000000)
#define ELF_SCRATCH ((unsigned char *)0x92800000)
extern const unsigned char blizzard_stub_start[], blizzard_stub_end[];
typedef struct { char name[80], path[240]; } Item;
static Item items[MAX_ITEMS];
static int count;
static char error[180];
static void fail(const char *s) { snprintf(error,sizeof error,"%s",s); }
static void ws(const char **p) { while (isspace((unsigned char)**p)) ++*p; }
static int literal(const char **p, const char *s) { size_t n=strlen(s); if(strncmp(*p,s,n)) return 0; *p+=n; return 1; }
/* Attribute values support the five XML predefined entities, not numeric entities. */
static int value(const char **p,char *out,size_t cap) {
    char quote=**p; size_t n=0; if(quote!='\'' && quote!='"') return 0; ++*p;
    while (**p && **p!=quote) {
        unsigned char c=(unsigned char)*(*p)++;
        if(c=='&') {
            if(literal(p,"amp;")) c='&'; else if(literal(p,"lt;")) c='<';
            else if(literal(p,"gt;")) c='>'; else if(literal(p,"quot;")) c='"';
            else if(literal(p,"apos;")) c='\''; else return 0;
        } else if(c=='<' || c<32) return 0;
        if(n+1>=cap) return 0;
        out[n++]=(char)c;
    }
    if(**p!=quote) return 0;
    ++*p; out[n]=0; return n!=0;
}
static int safe_path(const char *s) {
    size_t n=strlen(s); if(n<5 || s[0]=='/' || s[n-1]=='/') return 0;
    const char *part=s;
    for(const char *p=s;;p++) {
        unsigned char c=(unsigned char)*p;
        if(c=='/' || !c) { size_t len=(size_t)(p-part); if(!len || (len==1 && part[0]=='.') || (len==2 && part[0]=='.' && part[1]=='.')) return 0; part=p+1; if(!c) break; }
        else if(c<32 || c>=127 || strchr("\\:*?\"<>|",c)) return 0;
    }
    return (s[n-4]=='.' && ((tolower((unsigned char)s[n-3])=='d' && tolower((unsigned char)s[n-2])=='o' && tolower((unsigned char)s[n-1])=='l') || (tolower((unsigned char)s[n-3])=='e' && tolower((unsigned char)s[n-2])=='l' && tolower((unsigned char)s[n-1])=='f')));
}
static int parse_xml(const char *p) {
    ws(&p); if(literal(&p,"<?xml")) { const char *e=strstr(p,"?>"); if(!e) goto bad; p=e+2; ws(&p); }
    if(!literal(&p,"<payloads>")) goto bad;
    for(;;) {
        ws(&p); if(literal(&p,"</payloads>")) break;
        if(!literal(&p,"<payload") || !isspace((unsigned char)*p) || count==MAX_ITEMS) goto bad;
        Item item={{0},{0}}; int got_name=0,got_path=0;
        for(;;) {
            ws(&p); if(literal(&p,"/>")) break;
            char *dest; size_t cap;
            if(literal(&p,"name")) { if(got_name++) goto bad; dest=item.name; cap=sizeof item.name; }
            else if(literal(&p,"path")) { if(got_path++) goto bad; dest=item.path; cap=sizeof item.path; }
            else goto bad;
            ws(&p); if(*p++!='=') goto bad; ws(&p); if(!value(&p,dest,cap)) goto bad;
        }
        if(!got_name || !got_path || !safe_path(item.path)) goto bad;
        items[count++]=item;
    }
    ws(&p); if(*p) goto bad; return 1;
bad: fail("Invalid payloads.xml. Check the documented format and paths."); return 0;
}
static int load_config(void) {
    FILE *f=fopen("sd:/payloads/payloads.xml","rb"); if(!f) { fail("Cannot open sd:/payloads/payloads.xml"); return 0; }
    char *buf=malloc(MAX_XML+1); if(!buf) { fclose(f); fail("Out of memory reading XML."); return 0; }
    size_t n=fread(buf,1,MAX_XML+1,f); int io=ferror(f); fclose(f);
    if(io || n>MAX_XML || memchr(buf,0,n)) { free(buf); fail("XML read error, NUL byte, or file exceeds 32 KiB."); return 0; }
    buf[n]=0; count=0; int ok=parse_xml(buf); free(buf); return ok;
}
static uint32_t be32(const unsigned char *p) { return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3]; }
static int inside(uint32_t a,uint32_t n) { return a>=0x80004000u && a<0x81330000u && n<=0x81330000u-a; }
static int overlap(uint32_t a,uint32_t n,uint32_t b,uint32_t m) { return n && m && a < b+m && b < a+n; }
static int validate(const unsigned char *d,size_t size) {
    if(size<256) { fail("DOL header is truncated."); return 0; }
    uint32_t bss=be32(d+0xd8), bs=be32(d+0xdc), entry=be32(d+0xe0); int executable=0;
    if(bs && !inside(bss,bs)) { fail("DOL BSS is outside supported memory."); return 0; }
    for(int i=0;i<18;i++) {
        uint32_t off=be32(d+i*4), a=be32(d+0x48+i*4), n=be32(d+0x90+i*4);
        if(!n) continue;
        if(off<256 || off>size || n>size-off || !inside(a,n) || overlap(a,n,bss,bs)) { fail("DOL has an invalid or unsupported section."); return 0; }
        for(int j=0;j<i;j++) if(overlap(a,n,be32(d+0x48+j*4),be32(d+0x90+j*4))) { fail("DOL sections overlap."); return 0; }
        if(i<7 && entry>=a && entry-a<n) executable=1;
    }
    if(!executable || (entry&3)) { fail("DOL entry point is not in a text section."); return 0; }
    return 1;
}
static uint16_t be16(const unsigned char *p) { return (uint16_t)((p[0]<<8)|p[1]); }
static void put32(unsigned char *p,uint32_t x) { p[0]=x>>24; p[1]=x>>16; p[2]=x>>8; p[3]=x; }
/* Convert a static 32-bit big-endian PowerPC ELF to the DOL layout used by
   the relocation stub. PT_LOAD zero-filled tails become initialized bytes. */
static size_t convert_elf(const unsigned char *e,size_t size) {
    if(size<52 || memcmp(e,"\177ELF",4) || e[4]!=1 || e[5]!=2 || e[6]!=1 ||
       be16(e+16)!=2 || be16(e+18)!=20 || be32(e+20)!=1 || be16(e+40)<52) {
        fail("Unsupported ELF: expected a 32-bit big-endian PowerPC executable."); return 0;
    }
    uint32_t phoff=be32(e+28), entry=be32(e+24); uint16_t entsize=be16(e+42), num=be16(e+44);
    if(entsize<32 || !num || phoff>size || (size_t)num>(size-phoff)/entsize) {
        fail("ELF program header table is invalid."); return 0;
    }
    memset(ELF_SCRATCH,0,256); size_t out=256; int texts=0, datas=0, executable=0;
    for(unsigned i=0;i<num;i++) {
        const unsigned char *h=e+phoff+(size_t)i*entsize;
        uint32_t type=be32(h), off=be32(h+4), addr=be32(h+8), filesz=be32(h+16), memsz=be32(h+20), flags=be32(h+24);
        if(type==2 || type==3) { fail("Dynamic ELF executables are not supported."); return 0; }
        if(type!=1 || !memsz) continue;
        if(filesz>memsz || off>size || filesz>size-off || !inside(addr,memsz) || memsz>MAX_DOL-out) {
            fail("ELF has an invalid or unsupported load segment."); return 0;
        }
        int index;
        if(flags&1) { if(texts==7) { fail("ELF has too many executable segments."); return 0; } index=texts++; }
        else { if(datas==11) { fail("ELF has too many data segments."); return 0; } index=7+datas++; }
        for(int j=0;j<18;j++) if(overlap(addr,memsz,be32(ELF_SCRATCH+0x48+j*4),be32(ELF_SCRATCH+0x90+j*4))) {
            fail("ELF load segments overlap."); return 0;
        }
        memcpy(ELF_SCRATCH+out,e+off,filesz); memset(ELF_SCRATCH+out+filesz,0,memsz-filesz);
        put32(ELF_SCRATCH+index*4,(uint32_t)out); put32(ELF_SCRATCH+0x48+index*4,addr); put32(ELF_SCRATCH+0x90+index*4,memsz);
        if((flags&1) && entry>=addr && entry-addr<memsz) executable=1;
        out+=memsz;
    }
    if(!executable || (entry&3)) { fail("ELF entry point is not in an executable segment."); return 0; }
    put32(ELF_SCRATCH+0xe0,entry); memcpy(STAGING,ELF_SCRATCH,out); return out;
}
static int launch(const Item *item) {
    char path[260]; snprintf(path,sizeof path,"sd:/payloads/%s",item->path);
    FILE *f=fopen(path,"rb"); if(!f) { fail("Could not open payload. Check its path on the SD card."); return 0; }
    if(fseek(f,0,SEEK_END) || ftell(f)<0) { fclose(f); fail("Could not determine payload size."); return 0; }
    long len=ftell(f); rewind(f); if(len<256 || (unsigned long)len>MAX_DOL) { fclose(f); fail("Payload must be between 256 bytes and 8 MiB."); return 0; }
    if(fread(STAGING,1,(size_t)len,f)!=(size_t)len) { fclose(f); fail("Could not read the complete DOL."); return 0; } fclose(f);
    if(!memcmp(STAGING,"\177ELF",4)) { size_t converted=convert_elf(STAGING,(size_t)len); if(!converted) return 0; len=(long)converted; }
    if(!validate(STAGING,(size_t)len)) return 0;
    size_t stubsize=(size_t)(blizzard_stub_end-blizzard_stub_start);
    if(stubsize>4096) { fail("Internal loader stub is too large."); return 0; }
    memcpy(STUB,blizzard_stub_start,stubsize); DCFlushRange(STUB,stubsize); ICInvalidateRange(STUB,stubsize); DCFlushRange(STAGING,(u32)len);
    WPAD_Shutdown(); fatUnmount("sd"); SYS_ResetSystem(SYS_SHUTDOWN,0,0);
    ((void (*)(void *))STUB)(STAGING);
    for(;;) {}
}
static void draw(int selected) {
    printf("\x1b[0m\x1b[2J\x1b[H");
    printf("\x1b[36;1m\n  *  B L I Z Z A R D  *\x1b[0m\n");
    printf("\x1b[34;1m  ================================================\x1b[0m\n");
    printf("\x1b[37m  Your Wii homebrew, ready to launch.\x1b[0m\n\n");
    if(error[0]) printf("\x1b[31;1m  ! %.64s\x1b[0m\n\n",error);
    if(!count) printf("\x1b[33m  No payloads listed. Check payloads.xml.\x1b[0m\n");
    int start=selected/12*12, end=start+12; if(end>count) end=count;
    for(int i=start;i<end;i++) {
        if(i==selected) printf("\x1b[36;1m  > %-54.54s\x1b[0m\n",items[i].name);
        else printf("\x1b[37m    %-54.54s\x1b[0m\n",items[i].name);
    }
    printf("\n\x1b[34;1m  ================================================\x1b[0m\n");
    printf("\x1b[37m  UP/DOWN\x1b[0m select   \x1b[32;1mA\x1b[0m launch   \x1b[33;1mHOME\x1b[0m exit\n");
    printf("\x1b[36m  Payloads: %d\x1b[0m\n",count);
}
int main(void) {
    VIDEO_Init(); WPAD_Init(); GXRModeObj *mode=VIDEO_GetPreferredMode(NULL);
    void *fb=MEM_K0_TO_K1(SYS_AllocateFramebuffer(mode)); VIDEO_ClearFrameBuffer(mode,fb,COLOR_BLACK); console_init(fb,0,0,mode->fbWidth,mode->xfbHeight,mode->fbWidth*VI_DISPLAY_PIX_SZ);
    VIDEO_Configure(mode); VIDEO_SetNextFramebuffer(fb); VIDEO_SetBlack(FALSE); VIDEO_Flush(); VIDEO_WaitVSync(); if(mode->viTVMode&VI_NON_INTERLACE) VIDEO_WaitVSync();
    if(!fatInitDefault()) { fail("Could not mount SD card. Press HOME to exit."); draw(0); while(1) { WPAD_ScanPads(); if(WPAD_ButtonsDown(0)&WPAD_BUTTON_HOME) exit(0); VIDEO_WaitVSync(); } }
    load_config(); int selected=0; draw(selected);
    while(1) { WPAD_ScanPads(); u32 b=WPAD_ButtonsDown(0);
        if(b&WPAD_BUTTON_HOME) break;
        if(count && (b&WPAD_BUTTON_UP)) { selected=(selected+count-1)%count; error[0]=0; draw(selected); }
        if(count && (b&WPAD_BUTTON_DOWN)) { selected=(selected+1)%count; error[0]=0; draw(selected); }
        if(count && (b&WPAD_BUTTON_A)) { error[0]=0; launch(&items[selected]); draw(selected); }
        VIDEO_WaitVSync();
    }
    WPAD_Shutdown(); fatUnmount("sd"); return 0;
}
