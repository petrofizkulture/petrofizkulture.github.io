Blizzard 0.2.0
Example payloads are not included. Edit payloads/payloads.xml.
This package does not install the Homebrew Channel or include LetterBomb.
